"""TaskForge command line interface.

Usage:
    python -m taskforge serve --db PATH --port N
    python -m taskforge add --db PATH --title TEXT
    python -m taskforge list --db PATH
"""

import argparse
import sys

from .db import connect, create_task, init_db, list_tasks
from .server import serve


def cmd_add(args):
    conn = connect(args.db)
    try:
        init_db(conn)
        task_id = create_task(conn, args.title)
    finally:
        conn.close()
    print(task_id)


def cmd_list(args):
    conn = connect(args.db)
    try:
        init_db(conn)
        tasks = list_tasks(conn)
    finally:
        conn.close()
    for task in tasks:
        print(task["title"])


def do_serve(args):
    serve(args.db, args.port)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="taskforge", description="TaskForge task service"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_serve = sub.add_parser("serve", help="serve the HTTP API on 127.0.0.1")
    p_serve.add_argument("--db", required=True, help="path to SQLite database file")
    p_serve.add_argument("--port", required=True, type=int, help="TCP port to bind")
    p_serve.set_defaults(func=do_serve)

    p_add = sub.add_parser("add", help="add a task")
    p_add.add_argument("--db", required=True, help="path to SQLite database file")
    p_add.add_argument("--title", required=True, help="task title")
    p_add.set_defaults(func=cmd_add)

    p_list = sub.add_parser("list", help="list task titles")
    p_list.add_argument("--db", required=True, help="path to SQLite database file")
    p_list.set_defaults(func=cmd_list)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
