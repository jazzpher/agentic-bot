"""SQLite storage layer for TaskForge."""

import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
    key TEXT PRIMARY KEY,
    task_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES tasks(id)
);
"""


def connect(db_path):
    """Open a connection to the SQLite database file.

    Uses autocommit mode (isolation_level=None) so callers manage
    transactions explicitly with BEGIN IMMEDIATE / COMMIT, which is what
    makes concurrent writes safe.
    """
    conn = sqlite3.connect(db_path, timeout=30.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def init_db(conn):
    conn.executescript(SCHEMA)


def create_task(conn, title):
    cur = conn.execute("INSERT INTO tasks (title, done) VALUES (?, 0)", (title,))
    return cur.lastrowid


def list_tasks(conn, done=None):
    if done is None:
        cur = conn.execute("SELECT id, title, done FROM tasks ORDER BY id")
    else:
        cur = conn.execute(
            "SELECT id, title, done FROM tasks WHERE done = ? ORDER BY id",
            (1 if done else 0,),
        )
    return [
        {"id": row["id"], "title": row["title"], "done": bool(row["done"])}
        for row in cur.fetchall()
    ]


def get_task(conn, task_id):
    cur = conn.execute("SELECT id, title, done FROM tasks WHERE id = ?", (task_id,))
    row = cur.fetchone()
    if row is None:
        return None
    return {"id": row["id"], "title": row["title"], "done": bool(row["done"])}


def set_done(conn, task_id, done):
    cur = conn.execute(
        "UPDATE tasks SET done = ? WHERE id = ?", (1 if done else 0, task_id)
    )
    if cur.rowcount == 0:
        return None
    return get_task(conn, task_id)


def find_or_create_task(conn, title, idempotency_key=None):
    """Atomically reuse an idempotency key or insert a new task.

    Must be called inside a write transaction (BEGIN IMMEDIATE) so the
    check-then-insert is serialized against concurrent requests.
    Returns (task, created).
    """
    if idempotency_key is not None:
        cur = conn.execute(
            "SELECT task_id FROM idempotency_keys WHERE key = ?", (idempotency_key,)
        )
        row = cur.fetchone()
        if row is not None:
            return get_task(conn, row["task_id"]), False
    task_id = create_task(conn, title)
    task = get_task(conn, task_id)
    if idempotency_key is not None:
        conn.execute(
            "INSERT INTO idempotency_keys (key, task_id) VALUES (?, ?)",
            (idempotency_key, task_id),
        )
    return task, True
