# TaskForge

A stdlib-only Python task service backed by SQLite. No third-party
dependencies — just the Python standard library.

## Layout

- `taskforge/` — package (`__main__.py` CLI, `db.py` storage, `server.py` HTTP API)
- `test_taskforge.py` — unittest suite
- `README.md` — this file

## CLI

Start the HTTP service (binds `127.0.0.1`):

```
python -m taskforge serve --db /path/to/tasks.db --port 8000
```

Add a task:

```
python -m taskforge add --db /path/to/tasks.db --title "Write docs"
```

List task titles:

```
python -m taskforge list --db /path/to/tasks.db
```

## HTTP API

All bodies and responses are JSON.

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/` | HTML web UI for managing tasks |
| `GET` | `/tasks` | List all tasks: `[{id, title, done}, ...]` |
| `POST` | `/tasks` | Create `{"title": "..."}` → `201 {id, title, done}` |
| `PATCH` | `/tasks/ID` | Update `{"done": true}` → updated task object |

Query parameters:

- `GET /tasks?done=true` / `?done=false` filters by completion.
- Any other `done` value (or malformed requests) returns `400`.

Errors:

- Blank or non-string `title`, missing/invalid JSON → `400`
- Unknown task ID (PATCH) → `404`

### Idempotency

`POST /tasks` with an `Idempotency-Key` header replays the same task:
repeating the key returns the original task's `id` instead of creating a
duplicate. The check and insert happen in a single `BEGIN IMMEDIATE`
transaction, so it is safe under concurrent requests.

### Concurrency and persistence

Writes use `BEGIN IMMEDIATE` transactions on a WAL-mode SQLite database,
so concurrent writers are serialized by SQLite itself. All data lives in
the SQLite file given by `--db` and persists across restarts.

## Schema (v1)

```sql
CREATE TABLE tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0
);
```

An `idempotency_keys` table is also maintained internally.

## Tests

Run the test suite with the standard library test runner:

```
python -m unittest discover
```
